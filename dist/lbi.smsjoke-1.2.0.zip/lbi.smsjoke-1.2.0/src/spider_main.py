# coding:utf-8

from src import html_downloader, sms_manager

if __name__ == '__main__':
    downloader = html_downloader.HtmlDownloader()
    smsmanager = sms_manager.SMSManager()

    jokes = downloader.download()
    smsmanager.send_email(jokes)

    print('send success!')
