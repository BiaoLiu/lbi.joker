# coding:utf-8

from distutils.core import setup

setup(
    name="lbi.smsjoke",
    version="1.0.0",
    py_modules=['src.html_downloader', 'src.sms_manager', 'src.spider_main','src.config','src.redis_manager'],
    author="lbi",
    author_email="452381072@qq.com",
    url="",
    description="lbi.smsjoke"
)
