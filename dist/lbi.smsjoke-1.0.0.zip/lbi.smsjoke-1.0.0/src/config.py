#coding:utf-8

# 邮箱配置
mail_host = 'smtp.qq.com'
mail_user = '452381072@qq.com'
mail_password = 'lbxunzhbupc2875'

# 邮件接收人
# receivers=['liubiao2875@icloud.com']
receivers=['liubiao2875@icloud.com','1812390147@qq.com']

# redis配置
redis_config={
    'host':'120.27.46.167',
    'port':6379,
    'db':0
}
